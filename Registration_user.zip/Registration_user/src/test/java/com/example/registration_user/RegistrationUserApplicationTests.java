package com.example.registration_user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrationUserApplicationTests {

    @Test
    void contextLoads() {
    }

}
